<h1>Revosia Tickets bot</h1>
<H5>Bot de tickets pour le serveur Revosia</H5>
<p>Projet repris de Sayrix</p>

